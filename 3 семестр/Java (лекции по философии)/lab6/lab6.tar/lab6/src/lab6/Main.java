package lab6;


public class Main {
    public static void main(String[] args) {
        
    	Controller c = new Controller();
    	c.run();
         
    }
}