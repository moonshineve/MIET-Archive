/**
 * 
 */
/**
 * 
 */
module lab4 {
	requires java.logging;
}